# hostinger-sdk-php
composer require hostinger/hostinger-sdk-php
