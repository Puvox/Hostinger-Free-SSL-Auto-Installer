<?php

class HostingerApiException extends \Exception {

}