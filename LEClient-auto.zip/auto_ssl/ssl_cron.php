<?php

// YOUR VARIABLES
$email = 'YOUR_EMAIL@gmail.com';				// Email
$path_to_well_known = __DIR__.'/.well-known';	// Path to public "well-known" folder
$path_to_keys = __DIR__.'/keys';				// Path to "keys" folder
$path_to_errorlog = __DIR__.'/error_log';		// Path to error-logs (if errors will trigger during process)
$path_to_LEClient = __DIR__.'/LEClient-master/vendor/autoload.php';	// Path to "LEClient" library
$enable_debug_output = false;					// Only enable when testing



// ======================================================================================== //
// ==================================== START ============================================= //
// ======================================================================================== //
ini_set('max_execution_time', 120);				// Sets the maximum execution time to two minutes, to be sure.
// Including the autoloader.
include $path_to_LEClient;

// Importing the classes.
use LEClient\LEClient;
use LEClient\LEOrder;
function rmdir_recursive($path){
	if(!empty($path) && is_dir($path) ){
		$dir  = new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS); //upper dirs not included,otherwise DISASTER HAPPENS :)
		$files = new RecursiveIteratorIterator($dir, RecursiveIteratorIterator::CHILD_FIRST);
		foreach ($files as $f) {if (is_file($f)) {unlink($f);} else {$empty_dirs[] = $f;} } if (!empty($empty_dirs)) {foreach ($empty_dirs as $eachDir) {rmdir($eachDir);}} rmdir($path);
		return true;
	}
	return true;
} 

try{
	// ################### if run from CRON shell directly, let's convert "arg=val&arg2=val2" args to $_GET
	if (!empty($argv)) {
		parse_str($argv[1], $_GET);
		//file_put_contents(__DIR__.'/args_log', print_r($argv,true) );	 file_put_contents(__DIR__.'/get_log', print_r($_GET,true) );	
	}
	// ####################
	if (empty($_GET)) exit("parameters are empty. Please check documentation");

	$email = array($email);				// Listing the contact information in case a new account has to be created.
	$basename = $_GET['basename'];		// Defining the base name for this order
	$domains = $_GET['domains'];		// Listing the domains to be included on the certificate


	// Initiating the client instance. In this case using the staging server (argument 2) and outputting all status and debug information (argument 3).
	$client = new LEClient($email, false, LECLient::LOG_STATUS);
	// Initiating the order instance. The keys and certificate will be stored in /example.org/ (argument 1) and the domains in the array (argument 2) will be on the certificate.
	$order = $client->getOrCreateOrder($basename, $domains);
	// Check whether there are any authorizations pending. If that is the case, try to verify the pending authorizations.
	if(!$order->allAuthorizationsValid())
	{
		// Get the HTTP challenges from the pending authorizations.
		$pending = $order->getPendingAuthorizations(LEOrder::CHALLENGE_TYPE_HTTP);
		// Walk the list of pending authorization HTTP challenges. Example of the result array: https://pastebin.com/raw/By0cqN5w
		if(!empty($pending))
		{
			foreach($pending as $challenge)
			{ 
				// Define the folder in which to store the challenge. For the purpose of this example, a fictitious path is set.  
				$folder = $path_to_well_known .'/acme-challenge/';
				// Check if that directory yet exists. If not, create it.
				if(!file_exists($folder)) mkdir($folder, 0777, true);
				// Store the challenge file for this domain.
				file_put_contents($folder . $challenge['filename'], $challenge['content']);
				// Let LetsEncrypt verify this challenge.
				$order->verifyPendingOrderAuthorization($challenge['identifier'], LEOrder::CHALLENGE_TYPE_HTTP);
			}
		}
	}
	// Check once more whether all authorizations are valid before we can finalize the order.
	if($order->allAuthorizationsValid())
	{
		// Finalize the order first, if that is not yet done.
		if(!$order->isFinalized()) $order->finalizeOrder();
		// Check whether the order has been finalized before we can get the certificate. If finalized, get the certificate.
		if($order->isFinalized()) {
			$order->getCertificate();
			mail($email[0], 'SSL files for : '.$basename,  file_get_contents($path_to_keys. '/certificate.crt') .PHP_EOL . PHP_EOL . file_get_contents($path_to_keys. '/private.pem'), $headers ='From: ssl_issued@'.$basename . "\r\n" .  'Reply-To: ssl_issued@'.$basename . "\r\n" .  'X-Mailer: PHP/' . phpversion() );
			echo '<span style="font-size:2em; color:green;>SUCCESSFULLY MAILED (check your spambox)</span>';
		}
	}
}
catch(Exception $e){
	if ($enable_debug_output) var_dump($e);
	//file_put_contents(__FILE__.'_ERRORS_EXCEPTION', print_r($e,true) );	
}
finally{
	// remove traces after processing
	if (is_dir($path_to_keys)) rmdir_recursive($path_to_keys);
	if (is_dir($path_to_well_known)) rmdir_recursive($path_to_well_known);
	if (file_exists($path_to_errorlog)) unlink($path_to_errorlog);
}
?>